'use strict';
define([
    'angular',
    'components/angular_libraries/directives/ucsdToolTips'
], function(angular) {
    return angular.module('ucsdDirectives', [])
        .directive('tooltipFollow', ucsdToolTips);
});