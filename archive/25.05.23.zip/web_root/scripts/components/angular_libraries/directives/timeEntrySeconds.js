// components/angular_libraries/directives/timeEntrySeconds.js
'use strict';
define(function() {
    return [function() {
        return {
            restrict: 'A',
            require: 'ngModel',
            link: function(scope, element, attrs, ngModel) {

                // Converts seconds to "hh:mm AM/PM" string
                function format(seconds) {
                    if (seconds == null || isNaN(seconds)) return '';
                    let hours = Math.floor(seconds / 3600);
                    let minutes = Math.floor((seconds % 3600) / 60);
                    const ampm = hours >= 12 ? 'PM' : 'AM';
                    hours = hours % 12;
                    if (hours === 0) hours = 12;
                    return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')} ${ampm}`;
                }

                // Converts "hh:mm AM/PM" string to seconds
                function parse(input) {
                    if (!input) return undefined;
                    const match = input.trim().match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/i);
                    if (!match) return undefined;

                    let hours = parseInt(match[1], 10);
                    const minutes = parseInt(match[2], 10);
                    const ampm = match[3].toUpperCase();

                    if (hours < 1 || hours > 12 || minutes > 59) return undefined;

                    if (ampm === 'PM' && hours !== 12) hours += 12;
                    if (ampm === 'AM' && hours === 12) hours = 0;

                    return hours * 3600 + minutes * 60;
                }

                // View -> Model
                ngModel.$parsers.push(function(viewValue) {
                    const seconds = parse(viewValue);
                    ngModel.$setValidity('timeEntrySeconds', seconds != null);
                    return seconds;
                });

                // Model -> View
                ngModel.$formatters.push(function(modelValue) {
                    return format(modelValue);
                });

                // On blur, auto-correct formatting
                element.on('blur', function() {
                    const seconds = parse(element.val());
                    if (seconds != null) {
                        scope.$applyAsync(() => {
                            ngModel.$setViewValue(format(seconds));
                            ngModel.$render();
                        });
                    }
                });
            }
        };
    }];
});
