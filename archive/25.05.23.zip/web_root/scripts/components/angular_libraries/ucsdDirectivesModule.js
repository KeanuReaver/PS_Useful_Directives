'use strict';
define([
    'angular',
    'components/angular_libraries/directives/ucsdToolTips',
    'components/angular_libraries/directives/timeEntrySeconds'
], function(angular, ucsdToolTips, timeEntrySeconds) {
    return angular.module('ucsdDirectives', [])
        .directive('tooltipFollow', ucsdToolTips)
        .directive('timeEntrySeconds', timeEntrySeconds);
});