'use strict';
define(function(require) {
    const $j = require('jquery');
    return function dateEntryOracle() {
        return {
            restrict: 'A',
            require: 'ngModel',
            link: function(scope, element, attrs, ngModel) {
                // Inject CSS once
                (function injectStyles() {
                    if (document.getElementById('ucsdDateEntry-style')) return;
                    const style = document.createElement('style');
                    style.id = 'ucsdDateEntry-style';
                    style.textContent = `
                        input[data-date-entry-oracle] {
                            padding-left: 28px;
                            background-image: url("/images/img/icon-calendar.png");
                            background-repeat: no-repeat;
                            background-position: 6px center;
                            background-size: 16px 16px;
                            box-sizing: border-box;
                            width: auto;
                        }
                    `;
                    document.head.appendChild(style);
                })();

                // Format Oracle to MM/dd/yyyy
                ngModel.$formatters.push(function(value) {
                    if (!value) return '';
                    const parts = value.split(' ')[0].split('-');
                    if (parts.length !== 3) return value;
                    return `${parts[1]}/${parts[2]}/${parts[0]}`;
                });

                // Format MM/dd/yyyy to Oracle
                ngModel.$parsers.push(function(value) {
                    if (!value) return '';
                    const parts = value.split('/');
                    if (parts.length !== 3) return ngModel.$modelValue;
                    const [mm, dd, yyyy] = parts;
                    return `${yyyy}-${mm.padStart(2, '0')}-${dd.padStart(2, '0')}`;
                });

                // Add jQuery UI datepicker
                $j(element).datepicker({
                    dateFormat: 'mm/dd/yy',
                    onSelect: function(dateText) {
                        ngModel.$setViewValue(dateText);
                        ngModel.$render();
                    }
                });

                // Optional: up/down keys to adjust date
                element.on('keydown', function(event) {
                    const raw = ngModel.$modelValue;
                    if (!raw) return;

                    const datePart = raw.split(' ')[0];
                    const date = new Date(datePart);
                    if (isNaN(date)) return;

                    if (event.key === 'ArrowUp') {
                        date.setDate(date.getDate() + 1);
                    } else if (event.key === 'ArrowDown') {
                        date.setDate(date.getDate() - 1);
                    } else {
                        return;
                    }

                    const mm = String(date.getMonth() + 1).padStart(2, '0');
                    const dd = String(date.getDate()).padStart(2, '0');
                    const yyyy = date.getFullYear();
                    const formatted = `${mm}/${dd}/${yyyy}`;

                    ngModel.$setViewValue(formatted);
                    ngModel.$render();
                    event.preventDefault();
                });

                element.addClass('ucsdDateEntry');
            }
        };
    };
});