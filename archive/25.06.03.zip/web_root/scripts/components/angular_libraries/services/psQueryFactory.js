'use strict';
define(['angular', 'jquery'], function(angular, $j) {
    return angular.module('psQueryModule', []).factory('$psq', function() {
        const psQuery = function(table) {
            return new psQuery.init(table);
        };

        const stockTables = { address: "164", aggstats: "046", agg_attendance: "167", agg_att_detail: "171", attendance: "157", attendancequeue: "048", attendance_code: "156", attendance_conversion: "131", attendance_conversion_items: "132", attendance_taken: "172", attendance_time: "158", att_code_code_entity: "163", audit_log: "170", autocomm: "047", autosend: "049", awsched_constraint: "152", awsched_preference: "155", batches: "028", bell_schedule: "133", bell_schedule_items: "134", blobs: "012", books: "014", bulletinitems: "026", cache_message: "178", calendar: "029", calendar_day: "051", cc: "004", classrank: "015", code_entity: "162", component: "161", config_group: "176", coursefee: "104", courses: "002", course_relationship: "151", creq: "038", customdates: "185", customintegers: "181", customreals: "182", customtext: "183", customtimes: "186", customvarchars: "184", cycle_day: "135", dailyattendance: "084", dblog: "020", db_object: "169", db_version: "187", demographic: "166", department: "136", dialogs: "010", dnldqueue: "019", ds: "023", ethnicity: "168", facility: "137", fee: "146", fees: "054", fee_balance: "148", fee_transaction: "147", fee_type: "144", fields: "007", fieldtypechangerequest: "196", fte: "159", fte_grade: "160", gen: "006", gldetail: "025", gradescaleitem: "090", gradreq: "037", gradreqsets: "057", guardians: "055", help: "044", honorroll: "034", log: "008", log2: "050", logins: "016", mimetypes: "011", pages: "030", period: "138", pgassignments: "092", pgassignmentstandards: "093", pgcategories: "094", pgcommentbank: "097", pgfinalgrades: "095", pgfinalgradessetup: "191", pggradescales: "192", pggradescalesmark: "193", pgincomingqueue: "040", pgnotification: "173", pgpreferences: "043", pgscores: "096", pgsections: "195", pgstudents: "194", phonelog: "027", postsecondary: "165", prefs: "009", program: "174", queue: "024", reenrollments: "018", registreq: "056", relationship: "189", repobatchsetups: "101", repolookuptables: "065", repolookuptablescontentsitems: "067", repolookuptablescontrecords: "068", repolookuptablesdefitems: "066", reports: "022", reposetups: "059", reposetupsitems: "060", reposetupsorderby: "064", reposetupsqueries: "063", reposetupsqueryitems: "062", reposetupsuserdata: "061", reposetupsuserdatadefaults: "091", reposetupsvariables: "083", robj: "036", room: "139", scheduleactivitystatus: "073", schedulebldsessions: "114", schedulebuildcourserank: "116", schedulebuilddiagnostics: "118", schedulebuildings: "071", schedulebuilds: "105", schedulecatalogs: "109", schedulecc: "111", scheduleconstraints: "110", schedulecoursecatalogs: "107", schedulecourserelationships: "078", scheduledays: "075", scheduledepartments: "069", schedulefacilities: "076", schedulehouses: "072", scheduleitems: "052", scheduleloaddiagnostics: "119", scheduleloadtypes: "077", scheduleperiods: "080", schedulequeue: "113", schedulerequests: "082", schedulerooms: "081", scheduleroomtypes: "074", schedulesectionmeeting: "130", schedulesections: "112", schedulesectiontypes: "079", scheduleteacherassignments: "106", scheduleterms: "108", schedulevalidation: "117", schedulevalidterms: "070", sched_debug: "115", schoolfee: "145", schools: "039", schoolstaff: "203", school_course: "153", school_course_sched_parm: "154", sections: "003", sectionscores: "100", sectionscoresassignments: "198", sectionscoresid: "197", section_meeting: "140", selections: "085", seqno: "058", server_config: "175", server_instance: "177", sif_message: "179", spenrollments: "041", standardscurrent: "098", stateeventqueue: "102", stateextract_codeconversion: "128", stateextract_layoutelements: "127", stateextract_layouts: "126", statesupportdata: "021", statetransactionqueue: "103", stats: "017", storedgrades: "031", studentattendancesummary: "200", studentrace: "201", students: "001", studentschedulingresults: "190", studenttest: "087", studenttestscore: "089", sys_sequence: "180", teacherdailyload: "199", teacherrace: "202", teachers: "005", termbins: "033", terms: "013", test: "086", testscore: "088", transportation: "120", truancies: "042", ucols: "035", unschedstudschedlink: "143", unschedtermdayperiodslot: "142", unscheduledroom: "150", unscheduledstudent: "141", unscheduledteacher: "149", users: "204", utable: "032", virtualfieldsdef: "122", virtualtablesdata: "123", virtualtablesdata2: "125", virtualtablesdata3: "129", virtualtablesdef: "121", vs: "045", webasmt: "124" };

        psQuery.prototype = {
            delete: function(dcid, callback) {
                // call the update function with 'delete' as fields
                return this.update(dcid, 'delete', callback);
            },
            // insert, update, delete, get, etc. — all your methods
            insert: function(fields, callback) {
                // call the update function with a dcid as '-99'
                return this.update(-99, fields, callback);  
            },
            insertChild: function(parent, fields, callback) {
                // call the update function passing the parent table
                return this.update(parent, fields, callback);
            },
            update: function(dcid, fields, callback) {
            
                var self = this;
                var frn; // used for stock tables
                var parentStr;
                var parentID;
                
                // set url for AJAX call
                var url = '/admin/psQuery/psQueryA.html?no-store-lp=1';
                if (isGuardian) url = '/guardian/psQuery/psQueryP.html?g=1';
                if (isTeachers) url = '/teachers/psQuery/psQueryT.html?t=1';
                
                var isDelete = false;
                if (fields==='delete') isDelete = true;
                
                if (dcid !== null && typeof dcid === "object") {
                    
                    // must be insertChild, add the parent params to the URL
                    if (stockTables.hasOwnProperty(dcid.table)) {
                        parentStr = dcid.table + '.dcid';
                    } else {
                        parentStr = dcid.table + '.' + self.id_name;
                    }
                    parentID = dcid.id;
                    url = url + '&p=1&parentStr=' + parentStr + '&parentID=' + parentID;
                    dcid = -99;
                    
                }
                
                // determine the table type
                if (self.table_custom) {
                    if (isDelete) {
                        name_prefix = 'DD-' + self.table_name + '.ID:' + dcid;
                    } else {
                        name_prefix = 'CF-[' + self.table_name + ':' + dcid + ']';
                    }
                } else {
                    frn = self.table_number + String(dcid);
                    url = url + '&frn=' + frn;
                    if (isDelete) {
                        name_prefix = 'DR-' + frn;
                    } else {
                        name_prefix = '[' + self.table_number + ']';
                    }
                }
    
                // make sure fields is an object OR fields is 'delete'
                if ((fields !== null && typeof fields === 'object') || isDelete) {
                    
                    // map fields to key/name pairs for helper file (psQueryA.html, etc)
                    var count = 0;
                    var params = {};
                    var valuemap = ['prim'];
                    if (isGuardian) valuemap = ['autosendupdate'];
                    if (isTeachers) valuemap = ['webasmt'];
                    
                    if (isDelete) {
                        params.key1 = 1;
                        params.name1 = name_prefix;
                        valuemap.push(1);
                        
                    } else {
                        for (var k in fields) {
                            
                            if (fields.hasOwnProperty(k)) {
                                count++;
                                params['key'+count] = count;
                                params['name'+count] = name_prefix + k;
                                
                                // map the value for insertion later
                                valuemap.push(fields[k]);
                            }
                            
                            thisDataType = (typeof valuemap[count] === 'string' && !isNaN(new Date(valuemap[count])) && !isNaN(valuemap[count].charAt(0)) ) ? 'date' : 'notDate';
                            
                            if (count <= 2) {
                                if (valuemap[count] && Array.from(k)[0] !== '[' && !isDelete) {
                                    url += "&fieldName" + count + "=" + k + "&fieldVal"+ count + "=" + valuemap[count] + "&fieldDatatype" + count + "=" + thisDataType;
                                }
                            }
                            
                        }
    
                    }
                    // tell the query that this is a custom table, that is, it has a whencreated field
                    if (self.table_custom) url += "&iscustom=1";
                    
                    // the helper has a limit to the number of fields it can create/update ... edit the file to increase
                    if (count>self.maxParams) {
                        throw "psQuery: to many items in fields parameter";
                    }
                    
                    // call the helper file using jQuery's .post() method, passing the key/name gpv's
                    $j.post(encodeURI(url), params, function(retForm) {
                        
                        // get the returned form and serialize the names and insert the values
                        var formFields = $j(retForm).children("input");
                        var fieldData = {};
                        
                        count = 0;
                        formFields.each(function() {
                            fieldData[$j(this).attr("name")] = valuemap[count];
                            count++;
                        });
                        if (parentStr) fieldData[parentStr] = parentID;
                        
                        // add gpv's to URL (z, id_name, table_name)
                        url += '&table_name=' + self.table_name + '&id_name=' + self.id_name+ '&z=1';
                        
                        // sumbit (post) the data to the server, retValue is the ID
                        $j.post(encodeURI(url), fieldData, function(retID) {
                            
                            if (typeof callback === 'function') {
                                // valid retID for inserted records is the record that was created last (by dcid or by whencreated)
                                // valid retID for deleted or updated records is the record number of the orginal call (unless an error occured)
                                // a return of negative one (-1) means the retID of the inserted record was not found
                                
                                if (isNaN(retID)) {
                                    // check for query error (return zero/false)
                                    retID = 0;
                                    
                                } else {
                                    // any value (even a space) is considered a number.. convert the string to a number
                                    retID = Number(retID);
                                    
                                    // check for updated or deleted record and return the record number of the original call
                                    if (isDelete || dcid > 0) retID = dcid;
                                }
                                
                                callback(retID);
                                
                            } else {
                                return self;
                            }
                            
                        });
                        
                    });
    
                } else {
                    throw "psQuery: missing parameters";
                }
    
            },
            get: function(where_clause, return_fields, callback) {
            
                var self = this;
                
                // set url for AJAX call
                var url = '/admin/psQuery/psQueryA.html?no-store-lp=1';
                if (isGuardian) url = '/guardian/psQuery/psQueryP.html?g=1';
                if (isTeachers) url = '/teachers/psQuery/psQueryT.html?t=1';
                
                // this function is not available on the teacher and guardian portals for security reasons
                if (isGuardian || isTeachers) {
                    
                    throw "psQuery.get: not available in this portal";
                    
                } else {
                
                    // build tlist_sql framework based on passed in parameters
                    
                    // must have two parameters
                    if (where_clause === undefined || return_fields === undefined) {
                        
                        throw "psQuery: missing parameters";
                        
                    } else {
                    
                        // return_fields example: ["student_number", "lastfirst"] ... must be an array
                        if (!Array.isArray(return_fields)) {
                            return_fields = Array(return_fields);
                        }
            
                        // max 20 columns ... this creates blank columns as needed
                        var select = return_fields.concat(Array(20).fill("''")).slice(0,20);
                        url = url + '&z=1&q=1';
                        params = {'table_name': self.table_name, 'select_fields': select.join(), 'where_clause': where_clause};
                        
                        $j.post(encodeURI(url), params, function(json) {
                            
                            var data = JSON.parse(json);
                            data.pop();
                            var results = [];
                            var col_count = return_fields.length;
                            
                            // copy returned data to results array
                            data.forEach(function(row, idx) {
                                
                                var this_row = {};
                                for (let i = 0; i < col_count; i++) {
                                    
                                    var column_name = return_fields[i];
                                    
                                    // test for alias
                                    var has_alias = column_name.indexOf(" AS ");
                                    if (has_alias > 0) {
                                        column_name = column_name.substring(has_alias + 4);
                                    } 
                                    
                                    // put column value in column by name(alias)
                                    this_row[column_name] = row['c' + i];
                                    
                                }
                                results.push(this_row);
                                
                            });
                            
                            callback(results);
                            
                        });
                        
                    }
                
                }
                return this;
                
            }
        };

        psQuery.init = function(table) {
        
            var self = this;
            self.table_custom = false;
            self.id_name = 'dcid';
            if (table/1>0) {
                // table passed as a number, pad with zeros
                if (table/1 <= 999) { table = ("00"+table).slice(-3); }
                self.table_number = table;
    
                for(var k in stockTables) {
                    if(stockTables[k] === table) self.table_name = k;
                }
                
                if (self.table_name===undefined) {
                    throw "table not defined";
                }
    
            } else {
                if (stockTables[table]===undefined) {
                    // table could be a custom table
                    if (table.toUpperCase().substring(0,2)==='U_') {
                        self.table_custom = true;
                        self.table_name = table;
                        self.id_name = 'id';
                    } else {
                        throw "unknown table";
                    }
                    
                } else {
                    self.table_name = table;
                    self.table_number = stockTables[table];
                }
            }
            
        }

        psQuery.init.prototype = psQuery.prototype;
        
        return psQuery;
    });
});
