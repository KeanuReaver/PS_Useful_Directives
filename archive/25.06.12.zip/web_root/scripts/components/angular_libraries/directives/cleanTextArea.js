'use strict';
define(function(require) {
    return function cleanTextArea() {
        return {
            restrict: 'E',
            link: function(scope, elem) {
                elem.on('keydown', function(e) {
                    if (e.key === 'Enter' || e.key === 'Tab') {
                        e.preventDefault();
                    }
                });
                
                elem.on('input', function() {
                    const clean = elem.val().replace(/[\r\n\t]+/g, ' ');
                    if (clean !== elem.val()) {
                        elem.val(clean);
                    }
                });
            }
        };
    };
});