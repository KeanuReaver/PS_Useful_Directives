'use strict';
define(function() {
    return [function() {
        return {
            restrict: 'A',
            require: 'ngModel',
            link: function(scope, element, attrs, ngModel) {
                const stringMode = (
                    attrs.timeEntryString !== undefined ||
                    element.attr('data-time-entry-string') !== undefined
                );

                (function injectTimeEntryStyles() {
                    if (document.getElementById('ucsdTimeEntry-style')) return;
                    const style = document.createElement('style');
                    style.id = 'ucsdTimeEntry-style';
                    style.textContent = `
                        input[data-time-entry-seconds], input[time-entry-seconds] {
                            width: auto !important;
                            background-image: url("/images/img/icon-time.png");
                            background-repeat: no-repeat;
                            background-position: 2px center;
                            background-size: 16px 16px;
                            padding-left: 20px !important;
                        }
                    `;
                    document.head.appendChild(style);
                })();

                function formatSeconds(seconds) {
                    if (seconds == null || isNaN(seconds)) return '';
                    let hours = Math.floor(seconds / 3600);
                    let minutes = Math.floor((seconds % 3600) / 60);
                    const ampm = (hours >= 12) ? 'PM' : 'AM';
                    hours = (hours % 12);
                    if (hours === 0) hours = 12;
                    return (
                        String(hours).padStart(2, '0') +
                        ':' +
                        String(minutes).padStart(2, '0') +
                        ' ' +
                        ampm
                    );
                }

                function stringToSeconds(str) {
                    if (!str) return 28800;
                    const m = String(str).trim().match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/i);
                    if (!m) return NaN;
                    let h = parseInt(m[1], 10);
                    const mins = parseInt(m[2], 10);
                    const ampm = m[3].toUpperCase();
                    if (h < 1 || h > 12 || mins < 0 || mins > 59) return NaN;
                    if (ampm === 'PM' && h !== 12) h += 12;
                    if (ampm === 'AM' && h === 12) h = 0;
                    return h * 3600 + mins * 60;
                }

                function format(modelValue) {
                    if (modelValue == null || modelValue === '') {
                        return '';
                    }
                    if (stringMode) {
                        // modelValue is a "hh:mm AM/PM" string
                        const secs = stringToSeconds(modelValue);
                        return formatSeconds(secs);
                    } else {
                        const n = parseInt(modelValue, 10);
                        return formatSeconds(n);
                    }
                }

                function parse(viewValue) {
                    if (!viewValue) {
                        return stringMode ? '' : undefined;
                    }
                    const raw = String(viewValue).trim();
                    const m = raw.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/i);
                    if (!m) {
                        return stringMode ? raw : undefined;
                    }
                    let h = parseInt(m[1], 10);
                    const mins = parseInt(m[2], 10);
                    const ampm = m[3].toUpperCase();
                    if (h < 1 || h > 12 || mins < 0 || mins > 59) {
                        return stringMode ? raw : undefined;
                    }
                    if (ampm === 'PM' && h !== 12) h += 12;
                    if (ampm === 'AM' && h === 12) h = 0;
                    const secs = h * 3600 + mins * 60;
                    return stringMode ? formatSeconds(secs) : secs;
                }

                function adjustTime(bySeconds) {
                    const rawVal = element.val();
                    let currentSec;

                    if (stringMode) {
                        currentSec = stringToSeconds(rawVal);
                        if (isNaN(currentSec)) currentSec = 28800;
                    } else {
                        const p = parse(rawVal);
                        currentSec = (typeof p === 'number') ? p : 28800;
                    }

                    // clamp into [0,86399]
                    const nextSec = Math.max(0, Math.min(86399, currentSec + bySeconds));
                    const newDisplay = formatSeconds(nextSec);

                    scope.$applyAsync(() => {
                        if (stringMode) {
                            // In stringMode, model = canonical "hh:mm AM/PM"
                            ngModel.$setViewValue(newDisplay);
                        } else {
                            // In numeric mode, model = integer seconds
                            ngModel.$setViewValue(nextSec);
                        }
                        element.val(newDisplay);
                    });
                }

                ngModel.$parsers.push(function(viewValue) {
                    const parsed = parse(viewValue);
                    ngModel.$setValidity('timeEntrySeconds', parsed != null);
                    return parsed;
                });

                ngModel.$formatters.push(function(modelValue) {
                    return format(modelValue);
                });

                element.on('blur', function() {
                    const parsed = element.val();

                    scope.$applyAsync(() => {
                        if (parsed != null) {
                            ngModel.$setViewValue(parsed);
                        }
                        // Always replace whatever is in the textbox with the formatted time
                        const finalModel = ngModel.$modelValue;
                        element.val(format(finalModel));
                    });
                });

                element.on('keydown', function(e) {
                    if (e.key === 'ArrowUp') {
                        e.preventDefault();
                        adjustTime(300);
                    } else if (e.key === 'ArrowDown') {
                        e.preventDefault();
                        adjustTime(-300);
                    }
                });

                element.on('wheel', function(e) {
                    if (document.activeElement !== element[0]) return;
                    e.preventDefault();
                    const delta = e.originalEvent.deltaY;
                    adjustTime(delta < 0 ? 300 : -300);
                });
            }
        };
    }];
});